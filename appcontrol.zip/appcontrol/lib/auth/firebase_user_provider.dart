import 'package:firebase_auth/firebase_auth.dart';
import 'package:rxdart/rxdart.dart';

class AppcontrolFirebaseUser {
  AppcontrolFirebaseUser(this.user);
  User user;
  bool get loggedIn => user != null;
}

AppcontrolFirebaseUser currentUser;
bool get loggedIn => currentUser?.loggedIn ?? false;
Stream<AppcontrolFirebaseUser> appcontrolFirebaseUserStream() =>
    FirebaseAuth.instance
        .authStateChanges()
        .debounce((user) => user == null && !loggedIn
            ? TimerStream(true, const Duration(seconds: 1))
            : Stream.value(user))
        .map<AppcontrolFirebaseUser>(
            (user) => currentUser = AppcontrolFirebaseUser(user));
