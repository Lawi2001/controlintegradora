import 'package:firebase_auth/firebase_auth.dart';
import 'package:rxdart/rxdart.dart';

class ControlIntegradoraFirebaseUser {
  ControlIntegradoraFirebaseUser(this.user);
  User user;
  bool get loggedIn => user != null;
}

ControlIntegradoraFirebaseUser currentUser;
bool get loggedIn => currentUser?.loggedIn ?? false;
Stream<ControlIntegradoraFirebaseUser> controlIntegradoraFirebaseUserStream() =>
    FirebaseAuth.instance
        .authStateChanges()
        .debounce((user) => user == null && !loggedIn
            ? TimerStream(true, const Duration(seconds: 1))
            : Stream.value(user))
        .map<ControlIntegradoraFirebaseUser>(
            (user) => currentUser = ControlIntegradoraFirebaseUser(user));
