import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'controldesalidasentradas_record.g.dart';

abstract class ControldesalidasentradasRecord
    implements
        Built<ControldesalidasentradasRecord,
            ControldesalidasentradasRecordBuilder> {
  static Serializer<ControldesalidasentradasRecord> get serializer =>
      _$controldesalidasentradasRecordSerializer;

  @nullable
  BuiltList<DateTime> get salidas;

  @nullable
  BuiltList<String> get dia;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(
          ControldesalidasentradasRecordBuilder builder) =>
      builder
        ..salidas = ListBuilder()
        ..dia = ListBuilder();

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('controldesalidasentradas');

  static Stream<ControldesalidasentradasRecord> getDocument(
          DocumentReference ref) =>
      ref.snapshots().map(
          (s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<ControldesalidasentradasRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then(
          (s) => serializers.deserializeWith(serializer, serializedData(s)));

  ControldesalidasentradasRecord._();
  factory ControldesalidasentradasRecord(
          [void Function(ControldesalidasentradasRecordBuilder) updates]) =
      _$ControldesalidasentradasRecord;

  static ControldesalidasentradasRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createControldesalidasentradasRecordData() =>
    serializers.toFirestore(
        ControldesalidasentradasRecord.serializer,
        ControldesalidasentradasRecord((c) => c
          ..salidas = null
          ..dia = null));
